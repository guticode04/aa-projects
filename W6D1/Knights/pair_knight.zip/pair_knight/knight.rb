require_relative "node.rb"

class KnightPathFinder
  attr_reader :root_position

  class << self
    def valid_moves(position)
      # position = [0,0]
      positions = []

      first = position[0]
      last = position[1]

      positions << [first+2,last+1] unless first + 2 > 7 || last + 1 > 7
      positions << [first+2,last-1] unless first + 2 > 7 || last - 1 < 0
      positions << [first-2,last+1] unless first - 2 < 0 || last + 1 > 7
      positions << [first-2,last-1] unless first - 2 < 0 || last - 1 < 0 
      positions << [first+1,last+2] unless first + 1 > 7 || last + 2 > 7
      positions << [first+1,last-2] unless first + 1 > 7  || last - 2 < 0
      positions << [first-1,last+2] unless first - 1 < 0 || last + 2 > 7
      positions << [first-1,last-2] unless first - 1 < 0  || last - 2 < 0 

      positions
    end
  end

  def initialize(position) #position = [0,0]
    @root_position = PolyTreeNode.new(position)
    build_move_tree(@root_position)
  end

  def new_move_positions(position)
    positions = self.class.valid_moves(position) # => [[1,2],[2,1]]
    positions.select { |pos| #pos = [1,2]
      @considered_positions.none? { |node| node.value == pos } 
    }
  end

  def build_move_tree(position)
    # position = PolyTreeNode(0,0)
    # ...
    # self.class.valid_moves(position.value) # => [[1,2],[2,1]]
    
    @considered_positions = [position]

    nodes = [position]
    until nodes.empty?
      node = nodes.shift
      new_nodes = new_move_positions(node.value)


      new_nodes.each { |pos| 
        new_node = PolyTreeNode.new(pos)
        node.add_child(new_node)
        @considered_positions.push(new_node)
        nodes.push(new_node)
      }
    end

  end
end

