#Gustavo Gutierrez
class Array
  def merge_sort(&prc)
    

    #breakdown self
    middle = self.length / 2
    left = self[0...middle]
    right = self[middle..-1]

    #need to make recursive call
    merge(left.merge_sort(&prc), right.merge_sort(&prc), prc) 

    
   
  end

  Helper Method to handle merging
  def merge(left,right,prc)
    sorted = []

    #if no proc is given
    if prc.nil?
      prc = Proc.new { |ele1, ele2| ele1 <=> ele2 }
    end

    while left.length > 0 || right.length > 0
      #merge arrays according to prc
      #trying to compare arrays so should be left.first
      #right.first.should be elements
      if prc.call(left,right) == -1
        #should be making array smaller
        #using .shift right now infinite loop
        sorted << right.first        
      else
        sorted << left.first
      end
    end

    #merge arrays
    sorted + left + right
  end
end


Partner A Kenny
class Array 
#iterate thru the array 

    def my_flatten(level = nil)
        flat = []
        return self if level == 0 #base case
        if !level.nil?
            while level > 0
                if self[0].is_a?(Array)
                    self.shift.my_flatten(level - 1)
                else
                 flat << self.shift
            end 
          return self
        else
            while self.is_a(Array)
               if self[0].is_a?(Array)
                    self.shift.my_flatten()
                end 
            end  
            flat << self.shift 
        end 
        flat 
    end 

end 
[[c,d,[e]]] = > [c,d,[e]]

Partner B: Gustavo Gutierrez

"cats are cool".shuffled_sentence_detector("dogs are cool") => false
"cool cats are".shuffled_sentence_detector("cats are cool") => true

class String
  def shuffled_sentence_detector(sent)

    #split sent up to get each word
    new_sent = sent.split => [cats, are, cool]
    #split self
    original_sent = self.split => [cool, cats, are ]

    #iterate through one array and check to see
    #if other array includes it
    new_sent.each do |word| word => cats
      return false if !original_sent.include?(word)
    end

    #== works only on sorted arrays

    true
  end
end



Partner A: Kenny
#monkey patching 
class Array  # after do and inside {} are blocks
    def my_each(&prc)
        i = 0  #index to iterate thru Array
        while i < self.length  
            prc.call(self[i]) #places each ele in proc
            i += 1
        end 
        self 
    end 

end 

Partner B: Gustavo
#Monkey patching
class Array
  def my_reduce(accum = nil, &blck) [1,2,3,4] => 10
    #if no accum is given then the first ele is accum
    i = 0
    if accum.nil?
      accum = self.first
      i += 1
    end
    #result = 0
    while i < self.length
     accum = blck.call(accum,self[i])
     i += 1
    end
    accum
  end
end


Partner A: Kenny 
#monkey patching 
#dups
[1,2,3,0,3,0] => { 3 => [2,4] 0 => [3,5]}
class Array 
    #length, count, size 
    def mydups
        dups = Hash.new{|hash, k| hash[k]= []}

        #iterates thru each ele of the array and << it the hash with #ele as key
        self.each_with_index{|ele, idx| dups[ele] << idx } 
        #selects keys where value are greater then 1
        return dups.select{|_,v| v.count > 1}
    end 
end


Partner B: Gustavo
#count = 2 => [0, 1] count=1 => [0] count=3 [0,1,1]
#returns array of nth number of fib nums
def fibonacci_rec(n)
  return [] if n == 0
  return [0] if n == 1
  return [0,1] if n == 2

  # n = 4  
  fibs = fibonacci_rec(n - 1) => n = 3 [0,1,1] 
  next = fibs[-2] + fibs[-1] => 0 + 1
  fibs << next => fibs = [1,1,2]
  fibs

end

0! => 1 [1]
1! => 1 => [1,1]
2! => 2 => [1,1,2]
3! => 6 => 3 * 2 * 1 => [1,1,2,6]
find the n number factorials => n = 3 => [1,1,2,6]

Partner A: Kenny
def factorials_rec(n) n = 3 
    return [1] if n == 0
    return [1] if n == 1 
    arr = factorials_rec(n - 1)
    next = n * arr[-1]
    arr << next 
    arr
    
end 

# Without an argument:
[["a"], "b", ["c", "d", ["e"]]].my_flatten = ["a", "b", "c", "d", "e"]

# When given 1 as an argument:
# (Flattens the first level of nested arrays but no deeper)
[["a"], "b", ["c", "d", ["e"]]].my_flatten(1) = ["a", "b", "c", "d", ["e"]]
```
Partner B: Gustavo

class Array => [[1]]
  def my_flatten(level = nil)
    if level.nil?
      self.each do |ele|
        if ele.is_a?(Array)
          ele.my_flatten
        end
      end
    end
  end
end

def my_flatten
  return [] if length == 0

  self.each do |ele|
    if ele.is_a?(Array)
      ele.my_flatten
    end
  end
  self
end
